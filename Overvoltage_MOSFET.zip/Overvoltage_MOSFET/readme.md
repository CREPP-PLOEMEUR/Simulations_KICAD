Une simulation pour mettre en évidence le rôle de la diode de roue libre.
Cette diode permet de protéger l'organe de commutation (transistor).
